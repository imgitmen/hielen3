from ._base import BaseSchema


class PropertiesSchema(BaseSchema):
    pass
